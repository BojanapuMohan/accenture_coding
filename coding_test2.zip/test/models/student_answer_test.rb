require 'test_helper'

class StudentAnswerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
