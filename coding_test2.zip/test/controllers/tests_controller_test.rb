require 'test_helper'

class TestsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
