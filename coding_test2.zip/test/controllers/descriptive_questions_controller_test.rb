require 'test_helper'

class DescriptiveQuestionsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
