require 'test_helper'

class StudentTestTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
