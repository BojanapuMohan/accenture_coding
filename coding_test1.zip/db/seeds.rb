

 user = User.create(:name => "CEO", :role => "CEO", :email => "ceo@example.com" , :password => "hellohello"
                  )  
user = User.create(:name => "VP", :role => "VP", :email => "vp@example.com" , :password => "hellohello"
 ) 
user = User.create(:name => "Director", :role => "Director", :email => "director@example.com" , :password => "hellohello"
 ) 
user = User.create(:name => "Manager", :role => "Manager", :email => "manager@example.com" , :password => "hellohello"
 ) 
user = User.create(:name => "SDE", :role => "SDE", :email => "sde@example.com" , :password => "hellohello"  
 ) 