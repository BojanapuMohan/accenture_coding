class Employee < ActiveRecord::Base
end
